# Responsive CSS Tabs

A Pen created on CodePen.io. Original URL: [https://codepen.io/CaitFish/pen/bGOoYNe](https://codepen.io/CaitFish/pen/bGOoYNe).

